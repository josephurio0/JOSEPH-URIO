# JOTE SHOP PRO — Mwongozo wa Kusimika kwenye Seva (DEPLOY)

Lengo: kuweka programu kwenye seva salama inayopatikana kutoka vifaa vingi (simu za
wafanyakazi, kompyuta ya bosi) kwa **HTTPS**.

## 1. Mahitaji
- **Node.js 18+** (inafanya kazi vizuri 18/20/22). Hakuna haja ya compiler — hakuna
  utegemezi wa native.
- Seva ya Linux (VPS) yenye IP ya umma, au huduma kama Render/Railway/Fly.io.
- Jina la kikoa (domain) kwa ajili ya HTTPS (inashauriwa).

## 2. Pakua na sakinisha
```bash
unzip jote-shop-pro-server.zip
cd jote-shop-pro-server
npm install --omit=dev
```

## 3. Tengeneza `.env`
Tengeneza faili `.env` (usishiriki na mtu; usiiweke kwenye Git):
```ini
PORT=4055
# LAZIMA: siri ndefu ya random (angalau herufi 32). Tengeneza kwa:
#   node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
JWT_SECRET=weka_hapa_siri_ndefu_ya_random
# Siri ya MMILIKI ya kutengeneza namba za kuwezesha leseni (IWE TOFAUTI, usimpe bosi):
OWNER_SECRET=weka_hapa_siri_nyingine_ndefu
# Ufunguo wa endpoints za mmiliki (/api/owner/*):
OWNER_KEY=weka_hapa_ufunguo_wa_mmiliki
NODE_ENV=production
# Ruhusu kikoa chako tu (si '*') kwenye production:
CORS_ORIGIN=https://duka.mfano.com
TRIAL_DAYS=14
# Namba ya kupokea malipo (Tigo Pesa / Mixx by Yas):
PAY_PROVIDER=Tigo Pesa (Mixx by Yas)
PAY_NUMBER=0657443620
PAY_NAME=JOTE SHOP PRO
# Watumiaji wa mwanzo (hutumika mara ya kwanza tu):
SEED_BOSS_USER=boss
SEED_BOSS_PASS=badilisha1234
```
> Seva **itakataa kuanza** ikiwa `JWT_SECRET` ni fupi au haijawekwa — hii ni kinga.
> `OWNER_SECRET` na `OWNER_KEY` ndivyo vinavyofanya malipo yasikwepeke — vihifadhi
> kwa mmiliki tu, usiviweke kwenye kivinjari wala usivishiriki na bosi.

## 4. Endesha kama huduma (systemd)
Tengeneza `/etc/systemd/system/jote.service`:
```ini
[Unit]
Description=JOTE SHOP PRO
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/jote-shop-pro-server
EnvironmentFile=/opt/jote-shop-pro-server/.env
ExecStart=/usr/bin/node server.js
Restart=always
User=jote
# Seva ifunge kwa localhost tu; Nginx/Caddy itashughulikia umma:
Environment=HOST=127.0.0.1

[Install]
WantedBy=multi-user.target
```
```bash
sudo systemctl daemon-reload
sudo systemctl enable --now jote
```

## 5. HTTPS kwa reverse proxy (CHAGUA MOJA)

### Chaguo A — Caddy (rahisi, HTTPS otomatiki)
`/etc/caddy/Caddyfile`:
```
duka.mfano.com {
    reverse_proxy 127.0.0.1:4055
}
```
```bash
sudo systemctl reload caddy
```

### Chaguo B — Nginx + Certbot
`/etc/nginx/sites-available/jote`:
```nginx
server {
    listen 80;
    server_name duka.mfano.com;
    location / {
        proxy_pass http://127.0.0.1:4055;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```
```bash
sudo ln -s /etc/nginx/sites-available/jote /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d duka.mfano.com
```

## 6. Hatua za usalama (LAZIMA)
1. **Badilisha nenosiri za mwanzo** mara tu baada ya kuingia (`boss`/`kazi`).
2. Weka `JWT_SECRET` na `OWNER_SECRET` ndefu na za random; usiishiriki. Lazima ziwe tofauti.
3. Weka `OWNER_KEY` ya siri — ndiyo inayolinda endpoints za mmiliki.
4. Weka `PAY_NUMBER` iwe namba yako ya Tigo Pesa ya kupokelea malipo (chaguo-msingi 0657443620).
5. Weka `CORS_ORIGIN` kuwa kikoa chako tu (si `*`).
6. Tumia **HTTPS** kila wakati (hatua ya 5).
7. Firewall: ruhusu bandari 80/443 tu; seva ya Node ibaki 127.0.0.1.
8. Hifadhi nakala (backup) ya `jote-data.json` mara kwa mara (ndiyo data yote).

## 6b. Jinsi ya kupokea malipo na kuwezesha muda (mmiliki)
1. Bosi analipa kwa Tigo Pesa kwenda namba yako (`PAY_NUMBER`) na kutuma uthibitisho
   kupitia app (ukurasa wa “Leseni & Malipo” → “Nimelipa”).
2. Hakiki malipo kwenye simu yako ya Tigo. Kisha tengeneza namba ya kuwezesha:
   ```bash
   node owner-tools.js 30        # siku 30
   node owner-tools.js 365 7     # mwaka; itumike ndani ya siku 7
   ```
   (au `POST /api/owner/code` ukiwa na kichwa `x-owner-key: <OWNER_KEY>`).
3. Mpe bosi namba hiyo; yeye ataiweka kwenye app ili muda uongezwe. Namba hutumika
   mara moja tu.

## 7. Hifadhi nakala (backup)
```bash
# cron ya kila siku:
0 2 * * * cp /opt/jote-shop-pro-server/jote-data.json /backup/jote-$(date +\%F).json
```

## 8. Kuboresha / kusasisha
Simamisha huduma, badilisha faili za code (usiguse `.env` wala `jote-data.json`),
kisha `sudo systemctl restart jote`.

## Utatuzi wa matatizo
- **Seva haianzi, inasema JWT_SECRET**: weka `JWT_SECRET` ndefu kwenye `.env`.
- **Kivinjari hakiunganishi**: hakikisha reverse proxy inaelekeza 127.0.0.1:4055.
- **Haiwezi kuuza baada ya muda**: leseni ya jaribio imeisha — bosi arefreshe leseni.
