# JOTE SHOP PRO — Toleo la Seva (Server Edition)

Mfumo wa kusimamia duka kwa **bosi na wafanyakazi**, sasa ukiwa na **seva salama**,
**data inayoshirikiwa kati ya vifaa vingi** (simu/kompyuta tofauti), na **leseni ya
malipo kwa muda** (subscription) inayothibitishwa **upande wa seva** — haiwezi kukwepwa
kwa urahisi kama toleo la zamani la offline.

## Kwa nini toleo hili ni salama zaidi?
Katika toleo la zamani la faili moja la HTML, leseni na data vilihifadhiwa kwenye
kivinjari (localStorage), hivyo mtumiaji mjanja angeweza **kuzima leseni** au
kubadilisha data. Katika toleo hili:
- Nenosiri huhifadhiwa kama **bcrypt hash** (haipatikani kama maandishi).
- Kuingia hutumia **JWT token** yenye muda wa saa 12.
- **Stock, mauzo, na leseni** vinahesabiwa na kuthibitishwa **kwenye seva** — mteja
  hawezi kuuza zaidi ya stock au kuongeza muda wa leseni mwenyewe.
- `helmet` (vichwa vya usalama) + `express-rate-limit` (kuzuia mashambulizi ya
  kubahatisha nenosiri) vimewashwa.

## Teknolojia
- Node.js (Express) — API ya REST.
- Hifadhi ya data: faili moja la JSON (`jote-data.json`) likiwa na uandishi salama
  (temp + rename, ruhusa 0600). **Hakuna** utegemezi wa native (hakuna sqlite),
  hivyo husakinika popote bila kuhitaji compiler.
- Utegemezi wote ni pure-JS: `express, helmet, cors, express-rate-limit,
  bcryptjs, jsonwebtoken, dotenv`.

## Muundo wa faili
```
jote-shop-pro-server/
├── server.js        # API ya REST (mauzo, stock, madeni, watumiaji, leseni)
├── auth.js          # JWT + ruhusa za role + ukaguzi wa leseni
├── db.js            # hifadhi ya JSON (atomic write)
├── public/index.html# programu (frontend) iliyounganishwa na API
├── package.json
├── .env             # (unaitengeneza mwenyewe — ona DEPLOY.md)
├── README.md
└── DEPLOY.md
```

## Kuanza haraka (dev)
```bash
npm install
cp .env.example .env      # kisha weka JWT_SECRET ndefu ya random
node server.js            # itasikiliza 127.0.0.1:4055
```
Fungua kivinjari: `http://127.0.0.1:4055`

### Watumiaji wa mwanzo (BADILISHA MARA MOJA!)
| Jina      | Nenosiri        | Wajibu            |
|-----------|-----------------|-------------------|
| `boss`    | `badilisha1234` | msimamizi (bosi)  |
| `kazi`    | `badilisha1234` | mfanyakazi        |

> **Muhimu:** Baada ya kuingia mara ya kwanza, **badilisha nenosiri** kutoka ukurasa
> wa mipangilio. Usiache nenosiri la mwanzo kwenye seva halisi.

## API kwa muhtasari
- `POST /api/login` — ingia, pata token.
- `POST /api/change-password` — badilisha nenosiri.
- `GET  /api/state` — pata data yote ya duka (baada ya kuingia).
- `POST /api/products`, `PUT/DELETE /api/products/:id` — bidhaa (bosi).
- `POST /api/inputs` — ingiza mzigo (stock).
- `POST /api/sales` — uza (huthibitisha stock upande wa seva).
- `POST /api/debts`, `POST /api/debts/:id/pay` — madeni.
- `POST/DELETE /api/users` — wafanyakazi (bosi).
- `PUT /api/settings` — mipangilio ya duka.
- `POST /api/license/request` — bosi anatuma uthibitisho wa malipo (Tigo Pesa).
- `POST /api/license/activate` — bosi anaweka namba ya kuwezesha ili muda uongezwe.
- `PUT /api/license/prices` — badilisha bei zinazoonyeshwa (bosi).
- `GET /api/owner/payments`, `POST /api/owner/code` — za mmiliki (`x-owner-key`).

## Leseni / malipo (Tigo Pesa)
Muda wa jaribio (trial) huanza siku ya kwanza (chaguo-msingi siku 14, badilisha kwa
`TRIAL_DAYS`). Baada ya kuisha, vitendo vinavyohitaji leseni (mauzo, mzigo, madeni)
huzuiwa hadi muda uongezwe.

**Malipo yako salama — bosi HAWEZI kujiongezea muda bure.** Mtiririko ni:

1. **Bosi analipa** kwa **Tigo Pesa (Mixx by Yas)** kwenda namba **0657443620**
   (namba hii inawekwa kupitia `PAY_NUMBER`). Anapata SMS yenye namba ya muamala.
2. Kwenye ukurasa wa **“Leseni & Malipo”**, bosi anabonyeza **“Nimelipa”** kwenye
   mpango husika na kuweka namba ya muamala → inahifadhiwa kama **“inasubiri”**
   (haiongezi muda bado).
3. **Mmiliki wa mfumo (vendor)** anahakiki malipo kwenye simu yake ya Tigo, kisha
   anatengeneza **namba ya kuwezesha (activation code)** — ama kwa script
   `node owner-tools.js <siku>` (offline), au kupitia endpoint `/api/owner/code`
   (inalindwa kwa `OWNER_KEY`).
4. Bosi anaweka namba hiyo kwenye kisanduku cha **“activation code”** → seva
   inathibitisha saini (HMAC kwa `OWNER_SECRET`) na kuongeza muda.

Kwa nini haikwepeki: namba ya kuwezesha husainiwa kwa **`OWNER_SECRET`** ambayo
iko kwenye seva/kwa mmiliki tu. Bila siri hiyo, bosi hawezi kutengeneza namba
halali. Kila namba **hutumika mara moja** (nonce huhifadhiwa) na ina muda wa
kuisha.

### Zana ya mmiliki (offline)
```bash
node owner-tools.js 30        # namba ya kuongeza siku 30
node owner-tools.js 365 7     # namba ya mwaka, lazima itumike ndani ya siku 7
```

### Endpoints za mmiliki (kichwa `x-owner-key: <OWNER_KEY>`)
- `GET  /api/owner/payments` — ona malipo yaliyosubiri/kamili.
- `POST /api/owner/code` `{ days, validDays }` — tengeneza namba ya kuwezesha.
