'use strict';
require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const path = require('path');
const { data, save, uid, todayStr } = require('./db');
const { signToken, authRequired, adminRequired, licenseRequired, licenseActive, makeActivationCode, verifyActivationCode, ownerRequired } = require('./auth');

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);

/* ---------- Security middleware ---------- */
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.CORS_ORIGIN || '*', methods: ['GET', 'POST', 'PUT', 'DELETE'] }));
app.use(express.json({ limit: '256kb' }));

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 10, standardHeaders: true, legacyHeaders: false, message: { error: 'Umejaribu mara nyingi. Subiri dakika 15.' } });
const apiLimiter = rateLimit({ windowMs: 60 * 1000, max: 120, standardHeaders: true, legacyHeaders: false });
app.use('/api/', apiLimiter);

/* ---------- Helpers ---------- */
const num = v => (isFinite(+v) ? +v : 0);
function prod(id) { return data.products.find(p => p.id === id); }
function stockPieces(pid) {
  const i = data.inputs.filter(x => x.productId === pid).reduce((a, b) => a + b.pieces, 0);
  const o = data.sales.filter(x => x.productId === pid).reduce((a, b) => a + b.pieces, 0);
  return i - o;
}
function getState(user) {
  const out = {
    products: data.products,
    inputs: data.inputs,
    sales: data.sales,
    debts: data.debts,
    settings: {
      shopName: data.settings.shopName, phone: data.settings.phone,
      address: data.settings.address, currency: data.settings.currency,
      pay: data.settings.pay,
      license: { plan: data.license.plan, activatedOn: data.license.activatedOn, expiresOn: data.license.expiresOn, prices: data.license.prices }
    },
    receiptSeq: data.receiptSeq,
    payments: user.role === 'msimamizi' ? [...data.payments].slice(-30).reverse() : [],
    users: user.role === 'msimamizi' ? data.users.map(u => ({ id: u.id, username: u.username, name: u.name, role: u.role })) : []
  };
  return out;
}

/* ---------- AUTH ROUTES ---------- */
app.post('/api/login', loginLimiter, (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: 'Jaza jina na nenosiri' });
  const u = data.users.find(x => x.username === String(username).trim());
  if (!u || !bcrypt.compareSync(String(password), u.passHash)) {
    return res.status(401).json({ error: 'Jina au nenosiri si sahihi' });
  }
  res.json({ token: signToken(u), user: { id: u.id, name: u.name, role: u.role, username: u.username }, licenseActive: licenseActive() });
});

app.post('/api/change-password', authRequired, (req, res) => {
  const { oldPass, newPass } = req.body || {};
  if (!newPass || String(newPass).length < 4) return res.status(400).json({ error: 'Nenosiri jipya ni fupi mno' });
  const u = data.users.find(x => x.id === req.user.id);
  if (!bcrypt.compareSync(String(oldPass || ''), u.passHash)) return res.status(400).json({ error: 'Nenosiri la zamani si sahihi' });
  u.passHash = bcrypt.hashSync(String(newPass), 12); save();
  res.json({ ok: true });
});

app.get('/api/state', authRequired, (req, res) => {
  res.json({ state: getState(req.user), licenseActive: licenseActive(), me: req.user });
});

/* ---------- PRODUCTS (Msimamizi) ---------- */
function readProd(b) {
  return { name: String(b.name).trim(), perCarton: num(b.perCarton) || 1, buyPiece: num(b.buyPiece), sellPiece: num(b.sellPiece), buyCarton: num(b.buyCarton), sellCarton: num(b.sellCarton), reorder: num(b.reorder) || 5 };
}
app.post('/api/products', authRequired, adminRequired, (req, res) => {
  const b = req.body || {};
  if (!b.name || !String(b.name).trim()) return res.status(400).json({ error: 'Weka jina la bidhaa' });
  const p = Object.assign({ id: uid() }, readProd(b));
  data.products.push(p); save();
  res.json({ ok: true, id: p.id });
});
app.put('/api/products/:id', authRequired, adminRequired, (req, res) => {
  const p = prod(req.params.id);
  if (!p) return res.status(404).json({ error: 'Bidhaa haipo' });
  Object.assign(p, readProd(req.body || {})); save();
  res.json({ ok: true });
});
app.delete('/api/products/:id', authRequired, adminRequired, (req, res) => {
  data.products = data.products.filter(x => x.id !== req.params.id); save();
  res.json({ ok: true });
});

/* ---------- INPUTS (ingiza mzigo) ---------- */
app.post('/api/inputs', authRequired, licenseRequired, (req, res) => {
  const b = req.body || {};
  const p = prod(b.productId);
  if (!p) return res.status(400).json({ error: 'Chagua bidhaa sahihi' });
  const qty = num(b.qty); if (!(qty > 0)) return res.status(400).json({ error: 'Weka idadi sahihi' });
  const unit = b.unit === 'carton' ? 'carton' : 'piece';
  const buy = num(b.unitPrice) || (unit === 'carton' ? p.buyCarton : p.buyPiece);
  if (!(buy > 0)) return res.status(400).json({ error: 'Weka bei ya kununua' });
  const pieces = unit === 'carton' ? qty * (p.perCarton || 1) : qty;
  const date = /^\d{4}-\d{2}-\d{2}$/.test(b.date) ? b.date : todayStr();
  data.inputs.push({ id: uid(), date, productId: p.id, qty, unit, unitPrice: buy, pieces, total: buy * qty, user: req.user.name });
  save();
  res.json({ ok: true });
});
app.delete('/api/inputs/:id', authRequired, adminRequired, (req, res) => {
  data.inputs = data.inputs.filter(x => x.id !== req.params.id); save();
  res.json({ ok: true });
});

/* ---------- SALES (mauzo + risiti) ---------- */
app.post('/api/sales', authRequired, licenseRequired, (req, res) => {
  const b = req.body || {};
  const items = Array.isArray(b.items) ? b.items : [];
  if (!items.length) return res.status(400).json({ error: 'Risiti haina bidhaa' });
  const customer = (b.customer && String(b.customer).trim()) || 'Mteja';
  const pay = b.pay === 'debt' ? 'debt' : 'cash';
  // thibitisha stock (server-side)
  const need = {};
  const prepared = [];
  for (const it of items) {
    const p = prod(it.productId);
    if (!p) return res.status(400).json({ error: 'Bidhaa haipo' });
    const qty = num(it.qty); if (!(qty > 0)) return res.status(400).json({ error: 'Idadi si sahihi' });
    const unit = it.unit === 'carton' ? 'carton' : 'piece';
    const pieces = unit === 'carton' ? qty * (p.perCarton || 1) : qty;
    const price = unit === 'carton' ? p.sellCarton : p.sellPiece;
    if (!(price > 0)) return res.status(400).json({ error: 'Bei ya kuuza haijawekwa kwa ' + p.name });
    need[p.id] = (need[p.id] || 0) + pieces;
    if (need[p.id] > stockPieces(p.id)) return res.status(400).json({ error: 'Stock haitoshi kwa ' + p.name });
    prepared.push({ p, qty, unit, pieces, price, total: price * qty });
  }
  const rno = 'R' + String(data.receiptSeq).padStart(5, '0');
  data.receiptSeq++;
  const date = todayStr();
  let tot = 0;
  prepared.forEach(x => { data.sales.push({ id: uid(), date, productId: x.p.id, qty: x.qty, unit: x.unit, pieces: x.pieces, unitPrice: x.price, total: x.total, customer, salesperson: req.user.name, receiptNo: rno, pay }); tot += x.total; });
  if (pay === 'debt') data.debts.push({ id: uid(), date, customer, amount: tot, paid: 0, receiptNo: rno, status: 'wazi', user: req.user.name });
  save();
  res.json({ ok: true, rno, date, tot });
});

/* ---------- DEBTS (mikopo/madeni) ---------- */
app.post('/api/debts', authRequired, licenseRequired, (req, res) => {
  const b = req.body || {};
  const name = b.customer && String(b.customer).trim();
  const amt = num(b.amount);
  if (!name || !(amt > 0)) return res.status(400).json({ error: 'Jaza jina na kiasi' });
  data.debts.push({ id: uid(), date: todayStr(), customer: name, amount: amt, paid: 0, status: 'wazi', user: req.user.name });
  save();
  res.json({ ok: true });
});
app.post('/api/debts/:id/pay', authRequired, licenseRequired, (req, res) => {
  const d = data.debts.find(x => x.id === req.params.id);
  if (!d) return res.status(404).json({ error: 'Deni halipo' });
  const amt = num((req.body || {}).amount);
  if (!(amt > 0)) return res.status(400).json({ error: 'Kiasi si sahihi' });
  d.paid = Math.min(d.amount, d.paid + amt);
  d.status = d.paid >= d.amount ? 'imelipwa' : 'wazi';
  save();
  res.json({ ok: true });
});

/* ---------- USERS (Msimamizi) ---------- */
app.post('/api/users', authRequired, adminRequired, (req, res) => {
  const b = req.body || {};
  if (!b.name || !b.username || !b.pass) return res.status(400).json({ error: 'Jaza sehemu zote' });
  if (String(b.pass).length < 4) return res.status(400).json({ error: 'Nenosiri ni fupi mno' });
  if (data.users.some(u => u.username === String(b.username).trim())) return res.status(409).json({ error: 'Username ipo tayari' });
  const role = b.role === 'msimamizi' ? 'msimamizi' : 'mfanyakazi';
  data.users.push({ id: uid(), username: String(b.username).trim(), passHash: bcrypt.hashSync(String(b.pass), 12), name: String(b.name).trim(), role, createdAt: todayStr() });
  save();
  res.json({ ok: true });
});
app.delete('/api/users/:id', authRequired, adminRequired, (req, res) => {
  if (req.params.id === req.user.id) return res.status(400).json({ error: 'Huwezi kujifuta mwenyewe' });
  data.users = data.users.filter(x => x.id !== req.params.id); save();
  res.json({ ok: true });
});

/* ---------- SETTINGS (Msimamizi) ---------- */
app.put('/api/settings', authRequired, adminRequired, (req, res) => {
  const b = req.body || {};
  data.settings.shopName = String(b.shopName || 'JOTE SHOP PRO');
  data.settings.phone = String(b.phone || '');
  data.settings.address = String(b.address || '');
  data.settings.currency = String(b.currency || 'TZS');
  save();
  res.json({ ok: true });
});

/* ---------- LESENI / MALIPO KWA TIGO PESA ----------
   MFUMO SALAMA: bosi HAWEZI kuongeza muda mwenyewe. Hatua:
   1) Bosi analipa kwenye namba ya Tigo Pesa (vendor), kisha anatuma uthibitisho
      (txn code) kupitia /api/license/request => inahifadhiwa kama 'pending'.
   2) Mmiliki wa mfumo (vendor) anahakiki malipo, kisha anatengeneza namba ya
      kuwezesha (activation code) na kumpa bosi.
   3) Bosi anaingiza namba hiyo /api/license/activate => seva inathibitisha saini
      (HMAC kwa OWNER_SECRET) na kuongeza muda. Bila OWNER_SECRET, namba haiwezi
      kutengenezwa => malipo hayakwepeki. */
function extendLicenseDays(days, plan) {
  const base = licenseActive() ? new Date(data.license.expiresOn) : new Date();
  base.setDate(base.getDate() + days);
  if (plan) data.license.plan = plan;
  data.license.activatedOn = todayStr();
  data.license.expiresOn = base.toISOString().slice(0, 10);
}

/* Bosi anatuma uthibitisho wa malipo (haongezi muda bado) */
app.post('/api/license/request', authRequired, adminRequired, (req, res) => {
  const b = req.body || {};
  const days = parseInt(b.days, 10);
  if (![7, 30, 90, 365].includes(days)) return res.status(400).json({ error: 'Mpango si sahihi' });
  const txn = String(b.txn || '').trim();
  if (txn.length < 4) return res.status(400).json({ error: 'Weka namba ya uthibitisho wa Tigo Pesa (txn)' });
  const rec = {
    id: uid(), createdAt: new Date().toISOString(), date: todayStr(),
    days, plan: String(b.plan || ('Siku ' + days)),
    amount: num(b.amount), txn, phone: String(b.phone || '').trim(),
    by: req.user.name, status: 'pending'
  };
  data.payments.push(rec);
  save();
  res.json({ ok: true, id: rec.id, message: 'Uthibitisho umepokelewa. Subiri namba ya kuwezesha kutoka kwa mmiliki.' });
});

/* Bosi anaingiza namba ya kuwezesha (activation code) */
app.post('/api/license/activate', authRequired, adminRequired, (req, res) => {
  const code = String((req.body || {}).code || '').trim();
  const v = verifyActivationCode(code);
  if (!v.ok) return res.status(400).json({ error: v.error });
  if (data.usedCodes.includes(v.nonce)) return res.status(409).json({ error: 'Namba hii imekwisha tumika' });
  extendLicenseDays(v.days, 'Siku ' + v.days);
  data.usedCodes.push(v.nonce);
  // tia alama uthibitisho wa karibuni zaidi uliosubiri kuwa umekamilika
  const p = [...data.payments].reverse().find(x => x.status === 'pending' && x.days === v.days) ||
            [...data.payments].reverse().find(x => x.status === 'pending');
  if (p) { p.status = 'confirmed'; p.confirmedOn = todayStr(); }
  save();
  res.json({ ok: true, expiresOn: data.license.expiresOn, days: v.days });
});

/* Bosi anaweza kubadilisha bei zinazoonyeshwa (hiari) */
app.put('/api/license/prices', authRequired, adminRequired, (req, res) => {
  const p = req.body || {};
  data.license.prices = { '7': num(p['7']), '30': num(p['30']), '90': num(p['90']), '365': num(p['365']) };
  save();
  res.json({ ok: true });
});

/* ---------- MMILIKI WA MFUMO (vendor) — inalindwa kwa x-owner-key ---------- */
/* Ona malipo yaliyosubiri/kamili */
app.get('/api/owner/payments', ownerRequired, (req, res) => {
  res.json({ ok: true, payments: [...data.payments].reverse(), license: data.license });
});
/* Tengeneza namba ya kuwezesha kwa idadi ya siku (bila lazima kuwepo request) */
app.post('/api/owner/code', ownerRequired, (req, res) => {
  const days = parseInt((req.body || {}).days, 10);
  if (!(days > 0)) return res.status(400).json({ error: 'Weka idadi ya siku' });
  const validDays = parseInt((req.body || {}).validDays, 10) || 30;
  const code = makeActivationCode(days, validDays);
  // kama paymentId imetolewa, tia alama imeidhinishwa (bado itahitaji bosi aiwezeshe)
  const pid = (req.body || {}).paymentId;
  if (pid) { const p = data.payments.find(x => x.id === pid); if (p) { p.status = 'approved'; p.approvedOn = todayStr(); save(); } }
  res.json({ ok: true, code, days, expiresInDays: validDays });
});

/* ---------- Static frontend ---------- */
app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 4000;
/* Kwenye hosting, reverse-proxy (Nginx/Caddy) hushughulikia HTTPS */
app.listen(PORT, () => console.log('JOTE SHOP PRO server inasikiliza kwenye port ' + PORT));
