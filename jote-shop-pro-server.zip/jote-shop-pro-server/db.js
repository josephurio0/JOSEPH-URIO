'use strict';
/* ============================================================
   DATA LAYER (pure-JS, hakuna native build)
   - Inahifadhi kwenye faili moja la JSON kwa njia salama (atomic)
   - Manenosiri yamefichwa kwa bcrypt (kwenye auth/seed)
   - Hakuna SQL => hakuna SQL injection
   ============================================================ */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');

const DB_FILE = path.join(__dirname, 'jote-data.json');

function uid() {
  return Date.now().toString(36) + crypto.randomBytes(4).toString('hex');
}
function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

let data;
function load() {
  try {
    data = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  } catch (e) {
    data = null;
  }
}
/* Andika kwa usalama: andika faili la muda kisha badilisha jina (atomic) */
function save() {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data), { mode: 0o600 });
  fs.renameSync(tmp, DB_FILE);
}

function seed() {
  const trialDays = parseInt(process.env.TRIAL_DAYS || '14', 10);
  const e = new Date(); e.setDate(e.getDate() + trialDays);
  const bossUser = process.env.SEED_BOSS_USER || 'boss';
  const bossPass = process.env.SEED_BOSS_PASS || 'badilisha1234';
  data = {
    users: [
      { id: uid(), username: bossUser, passHash: bcrypt.hashSync(bossPass, 12), name: 'Mmiliki', role: 'msimamizi', createdAt: todayStr() },
      { id: uid(), username: 'kazi', passHash: bcrypt.hashSync('badilisha1234', 12), name: 'Mfanyakazi', role: 'mfanyakazi', createdAt: todayStr() }
    ],
    products: [], inputs: [], sales: [], debts: [],
    payments: [], usedCodes: [],
    settings: {
      shopName: 'JOTE SHOP PRO', phone: '', address: '', currency: 'TZS',
      pay: {
        provider: process.env.PAY_PROVIDER || 'Tigo Pesa (Mixx by Yas)',
        number: process.env.PAY_NUMBER || '0657443620',
        name: process.env.PAY_NAME || 'JOTE SHOP PRO'
      }
    },
    license: {
      plan: 'Jaribio (Trial)', activatedOn: todayStr(), expiresOn: e.toISOString().slice(0, 10),
      prices: { '7': 5000, '30': 15000, '90': 40000, '365': 120000 }
    },
    receiptSeq: 1
  };
  save();
}

load();
if (!data) seed();
/* hakikisha sehemu zote zipo (kwa data ya zamani) */
if (!data.license) { const e = new Date(); e.setDate(e.getDate() + 14); data.license = { plan: 'Jaribio (Trial)', activatedOn: todayStr(), expiresOn: e.toISOString().slice(0, 10), prices: { '7': 5000, '30': 15000, '90': 40000, '365': 120000 } }; save(); }
/* uhamiaji wa data ya zamani kwa malipo ya Tigo Pesa */
let _mig = false;
if (!Array.isArray(data.payments)) { data.payments = []; _mig = true; }
if (!Array.isArray(data.usedCodes)) { data.usedCodes = []; _mig = true; }
if (!data.settings.pay) {
  data.settings.pay = {
    provider: process.env.PAY_PROVIDER || 'Tigo Pesa (Mixx by Yas)',
    number: process.env.PAY_NUMBER || '0657443620',
    name: process.env.PAY_NAME || 'JOTE SHOP PRO'
  };
  _mig = true;
}
if (_mig) save();

module.exports = { data, save, uid, todayStr };
