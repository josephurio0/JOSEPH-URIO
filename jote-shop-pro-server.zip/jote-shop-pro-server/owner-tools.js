'use strict';
/* ============================================================
   ZANA ZA MMILIKI WA MFUMO (vendor)
   Tengeneza namba ya kuwezesha leseni (activation code) OFFLINE.
   Inatumia OWNER_SECRET ile ile iliyopo kwenye .env ya seva.

   MATUMIZI:
     node owner-tools.js <siku> [sikuZaKutumikaKwaNamba]
   MFANO:
     node owner-tools.js 30        # namba ya kuongeza siku 30 (hai kwa siku 30)
     node owner-tools.js 365 7     # namba ya mwaka, lazima itumike ndani ya siku 7

   Mpe bosi namba inayotoka; yeye ataiweka kwenye ukurasa wa "Leseni & Malipo".
   Namba hutumika MARA MOJA tu.
   ============================================================ */
require('dotenv').config();
const crypto = require('crypto');

const OWNER_SECRET = process.env.OWNER_SECRET || process.env.JWT_SECRET;
if (!OWNER_SECRET || OWNER_SECRET.length < 24) {
  console.error('\n[HITILAFU] Weka OWNER_SECRET (au JWT_SECRET) ndefu kwenye .env kwanza.\n');
  process.exit(1);
}

const days = parseInt(process.argv[2], 10);
const validDays = parseInt(process.argv[3], 10) || 30;
if (!(days > 0)) {
  console.error('Matumizi: node owner-tools.js <siku> [sikuZaKutumikaKwaNamba]');
  process.exit(1);
}

const nonce = crypto.randomBytes(4).toString('hex');
const exp = Math.floor(Date.now() / 86400000) + validDays;
const body = days + '.' + exp + '.' + nonce;
const sig = crypto.createHmac('sha256', OWNER_SECRET).update(body).digest('hex').slice(0, 16);
const code = 'JOTE-' + days + '-' + exp + '-' + nonce + '-' + sig;

console.log('\n================ NAMBA YA KUWEZESHA ================');
console.log('  Ongeza siku : ' + days);
console.log('  Itumike ndani ya siku : ' + validDays);
console.log('  NAMBA : ' + code);
console.log('===================================================');
console.log('Mpe bosi namba hii; ataiweka kwenye "Leseni & Malipo".\n');
