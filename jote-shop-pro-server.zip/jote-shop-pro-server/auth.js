'use strict';
/* ============================================================
   AUTHENTICATION & AUTHORIZATION
   - JWT iliyosainiwa kwa vikao
   - Middleware ya ruhusa (role) na leseni (muda)
   ============================================================ */
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { data } = require('./db');

const SECRET = process.env.JWT_SECRET;
if (!SECRET || SECRET.length < 24 || SECRET.includes('BADILISHA')) {
  console.error('\n[HITILAFU YA USALAMA] JWT_SECRET haijawekwa vizuri kwenye .env! Weka siri ndefu ya random.\n');
  process.exit(1);
}

/* Siri ya MMILIKI WA MFUMO (vendor) — hutumika kutengeneza/kuthibitisha namba za
   kuwezesha leseni (activation codes). HII NI TOFAUTI na JWT_SECRET na HAIPASWI
   kujulikana na bosi; ndiyo inayofanya malipo yasikwepwe. */
const OWNER_SECRET = process.env.OWNER_SECRET || SECRET;
const OWNER_KEY = process.env.OWNER_KEY || '';

function signToken(user) {
  return jwt.sign({ id: user.id, role: user.role, name: user.name }, SECRET, { expiresIn: '12h' });
}

function authRequired(req, res, next) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Hujaingia (token haipo)' });
  try {
    const payload = jwt.verify(token, SECRET);
    const u = data.users.find(x => x.id === payload.id);
    if (!u) return res.status(401).json({ error: 'Mtumiaji hayupo' });
    req.user = { id: u.id, username: u.username, name: u.name, role: u.role };
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Token si halali au imeisha muda' });
  }
}

function adminRequired(req, res, next) {
  if (!req.user || req.user.role !== 'msimamizi') {
    return res.status(403).json({ error: 'Ni Msimamizi pekee anayeruhusiwa' });
  }
  next();
}

function licenseActive() {
  return data.license && data.license.expiresOn >= new Date().toISOString().slice(0, 10);
}
function licenseRequired(req, res, next) {
  if (!licenseActive()) {
    return res.status(402).json({ error: 'Muda wa mfumo umeisha. Wasiliana na Msimamizi kuongeza muda.' });
  }
  next();
}

/* ---------- Namba ya kuwezesha leseni (activation code) ----------
   Umbo: JOTE-<days>-<expEpochDays>-<nonce>-<sig>
   sig = HMAC-SHA256("days.exp.nonce", OWNER_SECRET) herufi 16 za kwanza.
   Bosi hawezi kuitengeneza bila OWNER_SECRET => malipo hayakwepeki. */
function _sig(body) {
  return crypto.createHmac('sha256', OWNER_SECRET).update(body).digest('hex').slice(0, 16);
}
function makeActivationCode(days, validDays) {
  days = parseInt(days, 10);
  const nonce = crypto.randomBytes(4).toString('hex');
  // exp = siku ambayo namba hii yenyewe itakoma kutumika (default siku 30)
  const exp = Math.floor(Date.now() / 86400000) + (parseInt(validDays, 10) || 30);
  const body = days + '.' + exp + '.' + nonce;
  return 'JOTE-' + days + '-' + exp + '-' + nonce + '-' + _sig(body);
}
function verifyActivationCode(code) {
  if (!code || typeof code !== 'string') return { ok: false, error: 'Namba haipo' };
  const m = code.trim().match(/^JOTE-(\d+)-(\d+)-([0-9a-f]+)-([0-9a-f]{16})$/);
  if (!m) return { ok: false, error: 'Namba si sahihi' };
  const days = parseInt(m[1], 10), exp = parseInt(m[2], 10), nonce = m[3], sig = m[4];
  const body = days + '.' + exp + '.' + nonce;
  const expect = _sig(body);
  // linganisha kwa njia salama dhidi ya timing attacks
  const a = Buffer.from(sig), b = Buffer.from(expect);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return { ok: false, error: 'Namba si halali (saini haiendani)' };
  if (Math.floor(Date.now() / 86400000) > exp) return { ok: false, error: 'Namba imepita muda wake' };
  if (!(days > 0)) return { ok: false, error: 'Siku si sahihi' };
  return { ok: true, days, nonce };
}

/* Middleware ya MMILIKI (vendor) — kichwa x-owner-key lazima kilingane na OWNER_KEY */
function ownerRequired(req, res, next) {
  if (!OWNER_KEY) return res.status(503).json({ error: 'OWNER_KEY haijawekwa kwenye seva' });
  const k = req.headers['x-owner-key'] || '';
  const a = Buffer.from(String(k)), b = Buffer.from(OWNER_KEY);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return res.status(403).json({ error: 'Ruhusa ya mmiliki imekataliwa' });
  }
  next();
}

module.exports = { signToken, authRequired, adminRequired, licenseRequired, licenseActive, makeActivationCode, verifyActivationCode, ownerRequired };
